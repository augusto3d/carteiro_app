export const constants = {
  colors: {
    blue: "#0e6dfd",
    black: "#1c1c1c",
    white: "#ffffff",
  },
};
